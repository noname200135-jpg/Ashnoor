import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Basic config for Vercel deployment
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "images.unsplash.com",
      },
    ],
  },
};

export default nextConfig;
