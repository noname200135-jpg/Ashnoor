# ASHNOOR – Luxury Fashion E-commerce

A modern luxury fashion website built with **Next.js 15**, **TypeScript**, and **Tailwind CSS**.

## Features

- Dark elegant luxury theme (black + gold)
- Homepage with hero & featured products
- Product listing with category filters (Women / Men / Accessories)
- Product detail pages
- Working shopping cart (saved in browser)
- Checkout flow with order confirmation
- Fully responsive (mobile-friendly)

## Deploy to Vercel (Recommended)

### Easiest way from phone:

1. Create free account on **github.com**
2. Create a **New repository**
3. Upload all project files into the repository
4. Go to **vercel.com** and sign in with GitHub
5. Click **Add New... → Project**
6. Import your GitHub repository
7. Click **Deploy**

You will get a free live link like: `https://ashnoor-fashion.vercel.app`

## Run Locally (on computer)

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Brand

**ASHNOOR** – Luxury Fashion
