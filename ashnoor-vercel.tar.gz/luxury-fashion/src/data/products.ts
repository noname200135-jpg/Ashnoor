export type Product = {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  category: "women" | "men" | "accessories";
  description: string;
  details: string[];
  images: string[];
  colors: string[];
  sizes: string[];
  featured?: boolean;
  isNew?: boolean;
};

export const products: Product[] = [
  {
    id: "1",
    name: "Silk Evening Gown",
    price: 1890,
    originalPrice: 2200,
    category: "women",
    description:
      "An ethereal silk evening gown with cascading drapes and a subtle metallic sheen. Designed for nights that demand presence.",
    details: [
      "100% Mulberry silk",
      "Fully lined",
      "Hidden side zipper",
      "Dry clean only",
    ],
    images: [
      "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800&q=80",
      "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&q=80",
    ],
    colors: ["Black", "Champagne", "Deep Red"],
    sizes: ["XS", "S", "M", "L"],
    featured: true,
    isNew: true,
  },
  {
    id: "2",
    name: "Cashmere Overcoat",
    price: 2450,
    category: "men",
    description:
      "A masterfully tailored cashmere overcoat with a structured silhouette and soft hand-feel. The ultimate winter essential.",
    details: [
      "100% Cashmere",
      "Double-breasted",
      "Horn buttons",
      "Dry clean only",
    ],
    images: [
      "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=800&q=80",
      "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=800&q=80",
    ],
    colors: ["Camel", "Charcoal", "Navy"],
    sizes: ["S", "M", "L", "XL"],
    featured: true,
  },
  {
    id: "3",
    name: "Leather Tote Bag",
    price: 980,
    category: "accessories",
    description:
      "Handcrafted Italian leather tote with clean lines and solid brass hardware. Spacious yet refined.",
    details: [
      "Full-grain Italian leather",
      "Unlined interior",
      "Magnetic closure",
      "Made in Italy",
    ],
    images: [
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&q=80",
      "https://images.unsplash.com/photo-1590874103328-eac38a67472f?w=800&q=80",
    ],
    colors: ["Black", "Cognac", "Ivory"],
    sizes: ["One Size"],
    featured: true,
  },
  {
    id: "4",
    name: "Tailored Wool Blazer",
    price: 1250,
    category: "women",
    description:
      "A sharp, structured blazer in premium wool with a nipped waist and strong shoulders. Power dressing redefined.",
    details: [
      "Virgin wool blend",
      "Fully lined",
      "Mother-of-pearl buttons",
      "Dry clean only",
    ],
    images: [
      "https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=800&q=80",
      "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=800&q=80",
    ],
    colors: ["Black", "Ivory", "Camel"],
    sizes: ["XS", "S", "M", "L"],
    isNew: true,
  },
  {
    id: "5",
    name: "Merino Knit Sweater",
    price: 420,
    category: "men",
    description:
      "Ultra-soft merino wool sweater with a refined crew neck and clean finish. Everyday luxury.",
    details: [
      "100% Merino wool",
      "Ribbed cuffs and hem",
      "Machine wash cold",
    ],
    images: [
      "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800&q=80",
      "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=800&q=80",
    ],
    colors: ["Black", "Grey", "Navy", "Cream"],
    sizes: ["S", "M", "L", "XL"],
  },
  {
    id: "6",
    name: "Silk Scarf",
    price: 280,
    category: "accessories",
    description:
      "Hand-rolled edges and an exclusive print on pure silk. A versatile finishing touch.",
    details: [
      "100% Silk twill",
      "Hand-rolled hems",
      "90 × 90 cm",
      "Made in Italy",
    ],
    images: [
      "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=800&q=80",
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&q=80",
    ],
    colors: ["Gold", "Emerald", "Burgundy"],
    sizes: ["One Size"],
    isNew: true,
  },
  {
    id: "7",
    name: "Pleated Midi Skirt",
    price: 650,
    category: "women",
    description:
      "Fluid pleated midi skirt in a luxurious crepe fabric that moves beautifully with every step.",
    details: [
      "Crepe fabric",
      "Elastic waistband",
      "Fully lined",
      "Dry clean recommended",
    ],
    images: [
      "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=800&q=80",
      "https://images.unsplash.com/photo-1551163943-3f7e2e0e0e0e?w=800&q=80",
    ],
    colors: ["Black", "Ivory", "Dusty Rose"],
    sizes: ["XS", "S", "M", "L"],
  },
  {
    id: "8",
    name: "Oxford Dress Shirt",
    price: 320,
    category: "men",
    description:
      "Crisp cotton oxford shirt with mother-of-pearl buttons and a modern slim fit.",
    details: [
      "100% Cotton",
      "Mother-of-pearl buttons",
      "Machine washable",
    ],
    images: [
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=800&q=80",
      "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&q=80",
    ],
    colors: ["White", "Light Blue", "Pink"],
    sizes: ["S", "M", "L", "XL"],
  },
];

export function getProductById(id: string): Product | undefined {
  return products.find((p) => p.id === id);
}

export function getProductsByCategory(category?: string): Product[] {
  if (!category) return products;
  return products.filter((p) => p.category === category);
}

export function getFeaturedProducts(): Product[] {
  return products.filter((p) => p.featured);
}
