import Link from "next/link";

export default function Footer() {
  return (
    <footer className="border-t border-[#2a2a2a] bg-[#0a0a0a]">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-4">
          {/* Brand */}
          <div className="md:col-span-1">
            <span className="font-[family-name:var(--font-playfair)] text-xl font-semibold tracking-[0.15em] text-[#c9a962]">
              ASHNOOR
            </span>
            <p className="mt-4 text-sm leading-relaxed text-[#f5f5f0]/60">
              Timeless elegance for the modern connoisseur. Crafted with passion since 2024.
            </p>
          </div>

          {/* Shop */}
          <div>
            <h4 className="mb-4 text-xs font-medium tracking-[0.15em] text-[#c9a962]">
              SHOP
            </h4>
            <ul className="space-y-2 text-sm text-[#f5f5f0]/70">
              <li>
                <Link href="/products?category=women" className="hover:text-[#c9a962] transition">
                  Women
                </Link>
              </li>
              <li>
                <Link href="/products?category=men" className="hover:text-[#c9a962] transition">
                  Men
                </Link>
              </li>
              <li>
                <Link href="/products?category=accessories" className="hover:text-[#c9a962] transition">
                  Accessories
                </Link>
              </li>
              <li>
                <Link href="/products" className="hover:text-[#c9a962] transition">
                  New Arrivals
                </Link>
              </li>
            </ul>
          </div>

          {/* Help */}
          <div>
            <h4 className="mb-4 text-xs font-medium tracking-[0.15em] text-[#c9a962]">
              HELP
            </h4>
            <ul className="space-y-2 text-sm text-[#f5f5f0]/70">
              <li>
                <Link href="#" className="hover:text-[#c9a962] transition">
                  Shipping & Returns
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#c9a962] transition">
                  Size Guide
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#c9a962] transition">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#c9a962] transition">
                  FAQs
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h4 className="mb-4 text-xs font-medium tracking-[0.15em] text-[#c9a962]">
              STAY CONNECTED
            </h4>
            <p className="mb-3 text-sm text-[#f5f5f0]/60">
              Subscribe for exclusive offers and new arrivals.
            </p>
            <form className="flex gap-2">
              <input
                type="email"
                placeholder="Your email"
                className="flex-1 rounded-none border border-[#2a2a2a] bg-transparent px-3 py-2 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
              />
              <button
                type="submit"
                className="bg-[#c9a962] px-4 py-2 text-xs font-medium tracking-wider text-black transition hover:bg-[#e8d5a3]"
              >
                JOIN
              </button>
            </form>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-[#2a2a2a] pt-8 sm:flex-row">
          <p className="text-xs text-[#f5f5f0]/40">
            © 2026 ASHNOOR. All rights reserved.
          </p>
          <div className="flex gap-6 text-xs text-[#f5f5f0]/40">
            <Link href="#" className="hover:text-[#c9a962]">
              Privacy
            </Link>
            <Link href="#" className="hover:text-[#c9a962]">
              Terms
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
