"use client";

import { Product } from "@/data/products";
import { useState } from "react";

type Props = {
  product: Product;
};

export default function AddToCartButton({ product }: Props) {
  const [added, setAdded] = useState(false);

  const handleAdd = () => {
    // Simple localStorage cart for now
    const existing = JSON.parse(localStorage.getItem("ashnoor-cart") || "[]");
    const found = existing.find((item: any) => item.id === product.id);

    if (found) {
      found.quantity += 1;
    } else {
      existing.push({
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: 1,
      });
    }

    localStorage.setItem("ashnoor-cart", JSON.stringify(existing));
    window.dispatchEvent(new Event("cart-updated"));
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <button
      onClick={handleAdd}
      className={`w-full h-14 text-sm font-medium tracking-wider transition ${
        added
          ? "bg-green-700 text-white"
          : "bg-[#c9a962] text-black hover:bg-[#e8d5a3]"
      }`}
    >
      {added ? "ADDED TO CART ✓" : "ADD TO CART"}
    </button>
  );
}
