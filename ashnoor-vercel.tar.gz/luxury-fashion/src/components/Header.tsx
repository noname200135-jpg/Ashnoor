"use client";

import Link from "next/link";
import { useState, useEffect } from "react";

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    const updateCount = () => {
      try {
        const cart = JSON.parse(localStorage.getItem("ashnoor-cart") || "[]");
        const count = cart.reduce((sum: number, item: any) => sum + (item.quantity || 0), 0);
        setCartCount(count);
      } catch {
        setCartCount(0);
      }
    };

    updateCount();
    // Listen for storage changes (other tabs) and custom events
    window.addEventListener("storage", updateCount);
    window.addEventListener("cart-updated", updateCount);

    return () => {
      window.removeEventListener("storage", updateCount);
      window.removeEventListener("cart-updated", updateCount);
    };
  }, []);

  return (
    <header className="sticky top-0 z-50 border-b border-[#2a2a2a] bg-[#0a0a0a]/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <span className="font-[family-name:var(--font-playfair)] text-2xl font-semibold tracking-[0.15em] text-[#c9a962]">
            ASHNOOR
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden items-center gap-8 md:flex">
          <Link
            href="/products"
            className="text-sm tracking-wider text-[#f5f5f0]/80 transition hover:text-[#c9a962]"
          >
            SHOP
          </Link>
          <Link
            href="/products?category=women"
            className="text-sm tracking-wider text-[#f5f5f0]/80 transition hover:text-[#c9a962]"
          >
            WOMEN
          </Link>
          <Link
            href="/products?category=men"
            className="text-sm tracking-wider text-[#f5f5f0]/80 transition hover:text-[#c9a962]"
          >
            MEN
          </Link>
          <Link
            href="/products?category=accessories"
            className="text-sm tracking-wider text-[#f5f5f0]/80 transition hover:text-[#c9a962]"
          >
            ACCESSORIES
          </Link>
        </nav>

        {/* Right actions */}
        <div className="flex items-center gap-4">
          <button
            aria-label="Search"
            className="text-[#f5f5f0]/70 transition hover:text-[#c9a962]"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.3-4.3" />
            </svg>
          </button>

          <Link
            href="/cart"
            className="relative text-[#f5f5f0]/70 transition hover:text-[#c9a962]"
            aria-label="Cart"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" />
              <path d="M3 6h18" />
              <path d="M16 10a4 4 0 0 1-8 0" />
            </svg>
            {cartCount > 0 && (
              <span className="absolute -right-2 -top-2 flex h-4 w-4 items-center justify-center rounded-full bg-[#c9a962] text-[10px] font-medium text-black">
                {cartCount}
              </span>
            )}
          </Link>

          {/* Mobile menu button */}
          <button
            className="md:hidden text-[#f5f5f0]/70"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Menu"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              {mobileOpen ? (
                <path d="M18 6 6 18M6 6l12 12" />
              ) : (
                <>
                  <path d="M4 6h16" />
                  <path d="M4 12h16" />
                  <path d="M4 18h16" />
                </>
              )}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="border-t border-[#2a2a2a] bg-[#0a0a0a] px-4 py-4 md:hidden">
          <nav className="flex flex-col gap-4">
            <Link href="/products" className="text-sm tracking-wider" onClick={() => setMobileOpen(false)}>
              SHOP ALL
            </Link>
            <Link href="/products?category=women" className="text-sm tracking-wider" onClick={() => setMobileOpen(false)}>
              WOMEN
            </Link>
            <Link href="/products?category=men" className="text-sm tracking-wider" onClick={() => setMobileOpen(false)}>
              MEN
            </Link>
            <Link href="/products?category=accessories" className="text-sm tracking-wider" onClick={() => setMobileOpen(false)}>
              ACCESSORIES
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
