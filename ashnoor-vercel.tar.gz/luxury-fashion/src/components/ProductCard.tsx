import Link from "next/link";
import { Product } from "@/data/products";

type Props = {
  product: Product;
};

export default function ProductCard({ product }: Props) {
  return (
    <Link
      href={`/products/${product.id}`}
      className="group block fade-in hover-lift"
    >
      <div className="relative aspect-[3/4] overflow-hidden bg-[#1a1a1a]">
        {/* Placeholder gradient since external images may be blocked */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] via-[#2a2a2a] to-[#1a1a1a] transition duration-500 group-hover:scale-105" />
        
        {/* Product initial as elegant placeholder */}
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-[family-name:var(--font-playfair)] text-5xl font-light text-[#c9a962]/30">
            {product.name.charAt(0)}
          </span>
        </div>

        {/* Badges */}
        <div className="absolute left-3 top-3 flex flex-col gap-1">
          {product.isNew && (
            <span className="bg-[#c9a962] px-2 py-0.5 text-[10px] font-medium tracking-wider text-black">
              NEW
            </span>
          )}
          {product.originalPrice && (
            <span className="bg-black/70 px-2 py-0.5 text-[10px] font-medium tracking-wider text-[#c9a962]">
              SALE
            </span>
          )}
        </div>
      </div>

      <div className="mt-4 space-y-1">
        <p className="text-[11px] uppercase tracking-[0.15em] text-[#c9a962]/80">
          {product.category}
        </p>
        <h3 className="font-[family-name:var(--font-playfair)] text-lg text-[#f5f5f0] transition group-hover:text-[#c9a962]">
          {product.name}
        </h3>
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-[#f5f5f0]">
            ${product.price.toLocaleString()}
          </span>
          {product.originalPrice && (
            <span className="text-sm text-[#f5f5f0]/40 line-through">
              ${product.originalPrice.toLocaleString()}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
