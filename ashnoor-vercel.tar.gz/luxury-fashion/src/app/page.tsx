import Link from "next/link";
import ProductCard from "@/components/ProductCard";
import { getFeaturedProducts } from "@/data/products";

export default function HomePage() {
  const featured = getFeaturedProducts();

  return (
    <div className="fade-in">
      {/* Hero */}
      <section className="relative flex min-h-[85vh] items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0a0a] via-[#111] to-[#0a0a0a]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[#c9a962]/10 via-transparent to-transparent" />

        <div className="relative z-10 mx-auto max-w-4xl px-6 text-center">
          <p className="mb-4 text-xs tracking-[0.35em] text-[#c9a962]">
            NEW COLLECTION 2026
          </p>
          <h1 className="font-[family-name:var(--font-playfair)] text-5xl font-medium leading-tight tracking-tight text-[#f5f5f0] sm:text-6xl md:text-7xl">
            Timeless
            <br />
            <span className="text-[#c9a962]">Elegance</span>
          </h1>
          <p className="mx-auto mt-6 max-w-lg text-base leading-relaxed text-[#f5f5f0]/60">
            Discover pieces crafted for those who appreciate the quiet luxury of exceptional materials and flawless design.
          </p>
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link
              href="/products"
              className="inline-flex h-12 items-center justify-center bg-[#c9a962] px-8 text-sm font-medium tracking-wider text-black transition hover:bg-[#e8d5a3]"
            >
              SHOP THE COLLECTION
            </Link>
            <Link
              href="/products?category=women"
              className="inline-flex h-12 items-center justify-center border border-[#c9a962]/40 px-8 text-sm font-medium tracking-wider text-[#c9a962] transition hover:border-[#c9a962] hover:bg-[#c9a962]/10"
            >
              EXPLORE WOMEN
            </Link>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="border-t border-[#2a2a2a] py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 text-center">
            <h2 className="font-[family-name:var(--font-playfair)] text-3xl text-[#f5f5f0]">
              Shop by Category
            </h2>
          </div>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {[
              { name: "Women", href: "/products?category=women", desc: "Evening & Everyday" },
              { name: "Men", href: "/products?category=men", desc: "Tailoring & Knitwear" },
              { name: "Accessories", href: "/products?category=accessories", desc: "Bags, Scarves & More" },
            ].map((cat) => (
              <Link
                key={cat.name}
                href={cat.href}
                className="group relative flex aspect-[4/5] items-end overflow-hidden bg-[#1a1a1a] p-8 transition hover:bg-[#222]"
              >
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="relative">
                  <h3 className="font-[family-name:var(--font-playfair)] text-2xl text-[#f5f5f0] transition group-hover:text-[#c9a962]">
                    {cat.name}
                  </h3>
                  <p className="mt-1 text-sm text-[#f5f5f0]/50">{cat.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="border-t border-[#2a2a2a] py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 flex items-end justify-between">
            <div>
              <p className="text-xs tracking-[0.2em] text-[#c9a962]">CURATED</p>
              <h2 className="mt-2 font-[family-name:var(--font-playfair)] text-3xl text-[#f5f5f0]">
                Featured Pieces
              </h2>
            </div>
            <Link
              href="/products"
              className="hidden text-sm tracking-wider text-[#c9a962] transition hover:text-[#e8d5a3] sm:block"
            >
              VIEW ALL →
            </Link>
          </div>

          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="mt-10 text-center sm:hidden">
            <Link
              href="/products"
              className="text-sm tracking-wider text-[#c9a962]"
            >
              VIEW ALL →
            </Link>
          </div>
        </div>
      </section>

      {/* Brand statement */}
      <section className="border-t border-[#2a2a2a] py-24">
        <div className="mx-auto max-w-3xl px-6 text-center">
          <p className="font-[family-name:var(--font-playfair)] text-2xl leading-relaxed text-[#f5f5f0]/90 sm:text-3xl">
            “Luxury is not about labels.
            <br />
            It is about the quiet confidence of exceptional craft.”
          </p>
          <p className="mt-6 text-xs tracking-[0.2em] text-[#c9a962]">
            — ASHNOOR ATELIER
          </p>
        </div>
      </section>
    </div>
  );
}
