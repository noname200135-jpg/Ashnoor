"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type CartItem = {
  id: string;
  name: string;
  price: number;
  quantity: number;
};

export default function CartPage() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("ashnoor-cart") || "[]");
    setItems(stored);
    setLoaded(true);
  }, []);

  const updateQuantity = (id: string, delta: number) => {
    const updated = items
      .map((item) =>
        item.id === id
          ? { ...item, quantity: Math.max(0, item.quantity + delta) }
          : item
      )
      .filter((item) => item.quantity > 0);

    setItems(updated);
    localStorage.setItem("ashnoor-cart", JSON.stringify(updated));
  };

  const removeItem = (id: string) => {
    const updated = items.filter((item) => item.id !== id);
    setItems(updated);
    localStorage.setItem("ashnoor-cart", JSON.stringify(updated));
  };

  const subtotal = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  if (!loaded) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center text-[#f5f5f0]/50">
        Loading cart...
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center fade-in">
        <h1 className="font-[family-name:var(--font-playfair)] text-3xl text-[#f5f5f0]">
          Your Cart
        </h1>
        <p className="mt-4 text-[#f5f5f0]/50">Your cart is empty.</p>
        <Link
          href="/products"
          className="mt-8 inline-block bg-[#c9a962] px-8 py-3 text-sm font-medium tracking-wider text-black transition hover:bg-[#e8d5a3]"
        >
          CONTINUE SHOPPING
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 fade-in">
      <h1 className="font-[family-name:var(--font-playfair)] text-3xl text-[#f5f5f0]">
        Your Cart
      </h1>
      <p className="mt-2 text-sm text-[#f5f5f0]/50">
        {items.length} item{items.length !== 1 ? "s" : ""}
      </p>

      <div className="mt-10 space-y-6">
        {items.map((item) => (
          <div
            key={item.id}
            className="flex items-center justify-between border-b border-[#2a2a2a] pb-6"
          >
            <div>
              <h3 className="font-[family-name:var(--font-playfair)] text-lg text-[#f5f5f0]">
                {item.name}
              </h3>
              <p className="mt-1 text-sm text-[#f5f5f0]/60">
                ${item.price.toLocaleString()}
              </p>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center border border-[#2a2a2a]">
                <button
                  onClick={() => updateQuantity(item.id, -1)}
                  className="px-3 py-1 text-[#f5f5f0]/70 hover:text-[#c9a962]"
                >
                  −
                </button>
                <span className="w-8 text-center text-sm">{item.quantity}</span>
                <button
                  onClick={() => updateQuantity(item.id, 1)}
                  className="px-3 py-1 text-[#f5f5f0]/70 hover:text-[#c9a962]"
                >
                  +
                </button>
              </div>
              <p className="w-20 text-right text-sm font-medium">
                ${(item.price * item.quantity).toLocaleString()}
              </p>
              <button
                onClick={() => removeItem(item.id)}
                className="text-[#f5f5f0]/40 hover:text-red-400"
                aria-label="Remove"
              >
                ✕
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-10 border-t border-[#2a2a2a] pt-6">
        <div className="flex justify-between text-lg">
          <span className="text-[#f5f5f0]/70">Subtotal</span>
          <span className="font-medium text-[#f5f5f0]">
            ${subtotal.toLocaleString()}
          </span>
        </div>
        <p className="mt-2 text-xs text-[#f5f5f0]/40">
          Shipping & taxes calculated at checkout
        </p>

        <Link
          href="/checkout"
          className="mt-8 block w-full bg-[#c9a962] py-4 text-center text-sm font-medium tracking-wider text-black transition hover:bg-[#e8d5a3]"
        >
          PROCEED TO CHECKOUT
        </Link>
        <Link
          href="/products"
          className="mt-4 block text-center text-sm tracking-wider text-[#c9a962] hover:text-[#e8d5a3]"
        >
          Continue Shopping
        </Link>
      </div>
    </div>
  );
}
