"use client";

import { useState, useEffect } from "react";
import { products } from "@/data/products";
import Link from "next/link";

const ADMIN_PASSWORD = "ashnoor123"; // Change this later

export default function AdminPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [orders, setOrders] = useState<any[]>([]);

  useEffect(() => {
    // Check if already logged in
    if (typeof window !== "undefined") {
      const logged = sessionStorage.getItem("ashnoor-admin") === "true";
      setIsLoggedIn(logged);

      // Load any saved "orders" from localStorage (demo)
      const savedOrders = JSON.parse(localStorage.getItem("ashnoor-orders") || "[]");
      setOrders(savedOrders);
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      sessionStorage.setItem("ashnoor-admin", "true");
      setIsLoggedIn(true);
      setError("");
    } else {
      setError("Wrong password");
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem("ashnoor-admin");
    setIsLoggedIn(false);
  };

  if (!isLoggedIn) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-4 fade-in">
        <h1 className="font-[family-name:var(--font-playfair)] text-3xl text-[#f5f5f0]">
          Admin Login
        </h1>
        <p className="mt-2 text-sm text-[#f5f5f0]/50">ASHNOOR Dashboard</p>

        <form onSubmit={handleLogin} className="mt-10 w-full space-y-4">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter password"
            className="w-full border border-[#2a2a2a] bg-transparent px-4 py-3 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
          />
          {error && <p className="text-sm text-red-400">{error}</p>}
          <button
            type="submit"
            className="w-full bg-[#c9a962] py-3 text-sm font-medium tracking-wider text-black transition hover:bg-[#e8d5a3]"
          >
            LOGIN
          </button>
        </form>

        <p className="mt-8 text-xs text-[#f5f5f0]/30">
          Demo password: <span className="text-[#c9a962]">ashnoor123</span>
        </p>
      </div>
    );
  }

  // Calculate simple stats
  const totalProducts = products.length;
  const featuredCount = products.filter((p) => p.featured).length;
  const womenCount = products.filter((p) => p.category === "women").length;
  const menCount = products.filter((p) => p.category === "men").length;
  const accessoriesCount = products.filter((p) => p.category === "accessories").length;

  return (
    <div className="mx-auto max-w-5xl px-4 py-12 sm:px-6 fade-in">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-[family-name:var(--font-playfair)] text-3xl text-[#f5f5f0]">
            Admin Dashboard
          </h1>
          <p className="mt-1 text-sm text-[#f5f5f0]/50">ASHNOOR Management</p>
        </div>
        <div className="flex gap-3">
          <Link
            href="/"
            className="border border-[#2a2a2a] px-4 py-2 text-xs tracking-wider text-[#f5f5f0]/70 transition hover:border-[#c9a962] hover:text-[#c9a962]"
          >
            VIEW STORE
          </Link>
          <button
            onClick={handleLogout}
            className="bg-[#c9a962] px-4 py-2 text-xs font-medium tracking-wider text-black transition hover:bg-[#e8d5a3]"
          >
            LOGOUT
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="border border-[#2a2a2a] p-5">
          <p className="text-xs tracking-wider text-[#c9a962]">TOTAL PRODUCTS</p>
          <p className="mt-2 text-3xl font-medium text-[#f5f5f0]">{totalProducts}</p>
        </div>
        <div className="border border-[#2a2a2a] p-5">
          <p className="text-xs tracking-wider text-[#c9a962]">FEATURED</p>
          <p className="mt-2 text-3xl font-medium text-[#f5f5f0]">{featuredCount}</p>
        </div>
        <div className="border border-[#2a2a2a] p-5">
          <p className="text-xs tracking-wider text-[#c9a962]">WOMEN</p>
          <p className="mt-2 text-3xl font-medium text-[#f5f5f0]">{womenCount}</p>
        </div>
        <div className="border border-[#2a2a2a] p-5">
          <p className="text-xs tracking-wider text-[#c9a962]">MEN / ACCESSORIES</p>
          <p className="mt-2 text-3xl font-medium text-[#f5f5f0]">
            {menCount} / {accessoriesCount}
          </p>
        </div>
      </div>

      {/* Products Table */}
      <div className="mt-12">
        <h2 className="mb-6 text-xs tracking-[0.15em] text-[#c9a962]">
          ALL PRODUCTS
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-[#2a2a2a] text-[#f5f5f0]/50">
                <th className="pb-3 font-normal">ID</th>
                <th className="pb-3 font-normal">Name</th>
                <th className="pb-3 font-normal">Category</th>
                <th className="pb-3 font-normal">Price</th>
                <th className="pb-3 font-normal">Status</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <tr key={product.id} className="border-b border-[#2a2a2a]/50">
                  <td className="py-4 text-[#f5f5f0]/60">{product.id}</td>
                  <td className="py-4 font-[family-name:var(--font-playfair)] text-[#f5f5f0]">
                    {product.name}
                  </td>
                  <td className="py-4 capitalize text-[#f5f5f0]/70">
                    {product.category}
                  </td>
                  <td className="py-4 text-[#f5f5f0]">
                    ${product.price.toLocaleString()}
                  </td>
                  <td className="py-4">
                    {product.isNew && (
                      <span className="mr-2 bg-[#c9a962] px-2 py-0.5 text-[10px] text-black">
                        NEW
                      </span>
                    )}
                    {product.featured && (
                      <span className="bg-[#2a2a2a] px-2 py-0.5 text-[10px] text-[#c9a962]">
                        FEATURED
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Note */}
      <div className="mt-12 border border-[#2a2a2a] bg-[#111] p-6">
        <h3 className="text-xs tracking-[0.15em] text-[#c9a962]">NOTE</h3>
        <p className="mt-3 text-sm leading-relaxed text-[#f5f5f0]/60">
          This is a demo admin panel. Products are currently stored in the code.
          To add/edit products permanently, we need to connect a real database
          (like MongoDB or Supabase). You can ask me to add that later.
        </p>
        <p className="mt-3 text-sm text-[#f5f5f0]/60">
          <strong className="text-[#c9a962]">Admin URL:</strong> yourwebsite.com/admin
          <br />
          <strong className="text-[#c9a962]">Password:</strong> ashnoor123
        </p>
      </div>
    </div>
  );
}
