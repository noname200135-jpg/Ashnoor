import ProductCard from "@/components/ProductCard";
import { getProductsByCategory } from "@/data/products";
import Link from "next/link";

type Props = {
  searchParams: Promise<{ category?: string }>;
};

export default async function ProductsPage({ searchParams }: Props) {
  const params = await searchParams;
  const category = params.category;
  const products = getProductsByCategory(category);

  const title =
    category === "women"
      ? "Women"
      : category === "men"
      ? "Men"
      : category === "accessories"
      ? "Accessories"
      : "All Products";

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 fade-in">
      {/* Breadcrumb */}
      <div className="mb-8 flex items-center gap-2 text-sm text-[#f5f5f0]/50">
        <Link href="/" className="hover:text-[#c9a962]">
          Home
        </Link>
        <span>/</span>
        <span className="text-[#f5f5f0]">{title}</span>
      </div>

      <div className="mb-10 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-[family-name:var(--font-playfair)] text-4xl text-[#f5f5f0]">
            {title}
          </h1>
          <p className="mt-2 text-sm text-[#f5f5f0]/50">
            {products.length} piece{products.length !== 1 ? "s" : ""}
          </p>
        </div>

        {/* Category filters */}
        <div className="flex flex-wrap gap-2">
          {[
            { label: "All", value: "" },
            { label: "Women", value: "women" },
            { label: "Men", value: "men" },
            { label: "Accessories", value: "accessories" },
          ].map((f) => {
            const isActive = (category || "") === f.value;
            return (
              <Link
                key={f.value}
                href={f.value ? `/products?category=${f.value}` : "/products"}
                className={`px-4 py-1.5 text-xs tracking-wider transition ${
                  isActive
                    ? "bg-[#c9a962] text-black"
                    : "border border-[#2a2a2a] text-[#f5f5f0]/70 hover:border-[#c9a962] hover:text-[#c9a962]"
                }`}
              >
                {f.label}
              </Link>
            );
          })}
        </div>
      </div>

      {products.length === 0 ? (
        <p className="py-20 text-center text-[#f5f5f0]/50">
          No products found in this category.
        </p>
      ) : (
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
