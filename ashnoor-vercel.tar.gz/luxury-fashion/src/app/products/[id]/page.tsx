import { getProductById, products } from "@/data/products";
import Link from "next/link";
import { notFound } from "next/navigation";
import AddToCartButton from "@/components/AddToCartButton";

type Props = {
  params: Promise<{ id: string }>;
};

export function generateStaticParams() {
  return products.map((p) => ({ id: p.id }));
}

export default async function ProductPage({ params }: Props) {
  const { id } = await params;
  const product = getProductById(id);

  if (!product) {
    notFound();
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 fade-in">
      <div className="mb-8 flex items-center gap-2 text-sm text-[#f5f5f0]/50">
        <Link href="/" className="hover:text-[#c9a962]">
          Home
        </Link>
        <span>/</span>
        <Link href="/products" className="hover:text-[#c9a962]">
          Shop
        </Link>
        <span>/</span>
        <span className="text-[#f5f5f0]">{product.name}</span>
      </div>

      <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
        <div className="relative aspect-[3/4] overflow-hidden bg-[#1a1a1a]">
          <div className="absolute inset-0 bg-gradient-to-br from-[#1a1a1a] via-[#2a2a2a] to-[#1a1a1a]" />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="font-[family-name:var(--font-playfair)] text-8xl font-light text-[#c9a962]/20">
              {product.name.charAt(0)}
            </span>
          </div>
          {product.isNew && (
            <span className="absolute left-4 top-4 bg-[#c9a962] px-3 py-1 text-xs font-medium tracking-wider text-black">
              NEW
            </span>
          )}
        </div>

        <div className="flex flex-col">
          <p className="text-xs uppercase tracking-[0.2em] text-[#c9a962]">
            {product.category}
          </p>
          <h1 className="mt-2 font-[family-name:var(--font-playfair)] text-4xl text-[#f5f5f0]">
            {product.name}
          </h1>

          <div className="mt-4 flex items-center gap-3">
            <span className="text-2xl font-medium text-[#f5f5f0]">
              ${product.price.toLocaleString()}
            </span>
            {product.originalPrice && (
              <span className="text-lg text-[#f5f5f0]/40 line-through">
                ${product.originalPrice.toLocaleString()}
              </span>
            )}
          </div>

          <p className="mt-6 leading-relaxed text-[#f5f5f0]/70">
            {product.description}
          </p>

          <div className="mt-8">
            <p className="mb-3 text-xs tracking-[0.15em] text-[#f5f5f0]/50">
              COLOR
            </p>
            <div className="flex flex-wrap gap-2">
              {product.colors.map((color) => (
                <button
                  key={color}
                  className="border border-[#2a2a2a] px-4 py-2 text-sm text-[#f5f5f0]/80 transition hover:border-[#c9a962] hover:text-[#c9a962]"
                >
                  {color}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <p className="mb-3 text-xs tracking-[0.15em] text-[#f5f5f0]/50">
              SIZE
            </p>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((size) => (
                <button
                  key={size}
                  className="flex h-10 w-14 items-center justify-center border border-[#2a2a2a] text-sm text-[#f5f5f0]/80 transition hover:border-[#c9a962] hover:text-[#c9a962]"
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-10">
            <AddToCartButton product={product} />
          </div>

          <div className="mt-12 border-t border-[#2a2a2a] pt-8">
            <h3 className="text-xs tracking-[0.15em] text-[#c9a962]">
              DETAILS
            </h3>
            <ul className="mt-4 space-y-2">
              {product.details.map((detail) => (
                <li
                  key={detail}
                  className="flex items-start gap-2 text-sm text-[#f5f5f0]/70"
                >
                  <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-[#c9a962]" />
                  {detail}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
