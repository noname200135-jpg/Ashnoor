"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type CartItem = {
  id: string;
  name: string;
  price: number;
  quantity: number;
};

export default function CheckoutPage() {
  const [items, setItems] = useState<CartItem[]>([]);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("ashnoor-cart") || "[]");
    setItems(stored);
  }, []);

  const subtotal = items.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.removeItem("ashnoor-cart");
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center fade-in">
        <div className="mb-6 text-5xl text-[#c9a962]">✓</div>
        <h1 className="font-[family-name:var(--font-playfair)] text-3xl text-[#f5f5f0]">
          Order Confirmed
        </h1>
        <p className="mt-4 text-[#f5f5f0]/60">
          Thank you for your purchase. A confirmation email has been sent.
        </p>
        <Link
          href="/"
          className="mt-10 inline-block bg-[#c9a962] px-8 py-3 text-sm font-medium tracking-wider text-black transition hover:bg-[#e8d5a3]"
        >
          RETURN HOME
        </Link>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <p className="text-[#f5f5f0]/50">Your cart is empty.</p>
        <Link href="/products" className="mt-4 inline-block text-[#c9a962]">
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 fade-in">
      <h1 className="font-[family-name:var(--font-playfair)] text-3xl text-[#f5f5f0]">
        Checkout
      </h1>

      <div className="mt-10 grid gap-12 lg:grid-cols-5">
        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6 lg:col-span-3">
          <div>
            <h2 className="mb-4 text-xs tracking-[0.15em] text-[#c9a962]">
              CONTACT
            </h2>
            <input
              required
              type="email"
              placeholder="Email address"
              className="w-full border border-[#2a2a2a] bg-transparent px-4 py-3 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
            />
          </div>

          <div>
            <h2 className="mb-4 text-xs tracking-[0.15em] text-[#c9a962]">
              SHIPPING ADDRESS
            </h2>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <input
                  required
                  placeholder="First name"
                  className="border border-[#2a2a2a] bg-transparent px-4 py-3 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
                />
                <input
                  required
                  placeholder="Last name"
                  className="border border-[#2a2a2a] bg-transparent px-4 py-3 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
                />
              </div>
              <input
                required
                placeholder="Address"
                className="w-full border border-[#2a2a2a] bg-transparent px-4 py-3 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
              />
              <div className="grid grid-cols-2 gap-3">
                <input
                  required
                  placeholder="City"
                  className="border border-[#2a2a2a] bg-transparent px-4 py-3 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
                />
                <input
                  required
                  placeholder="Postal code"
                  className="border border-[#2a2a2a] bg-transparent px-4 py-3 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div>
            <h2 className="mb-4 text-xs tracking-[0.15em] text-[#c9a962]">
              PAYMENT
            </h2>
            <p className="mb-3 text-xs text-[#f5f5f0]/40">
              This is a demo — no real payment will be processed.
            </p>
            <input
              required
              placeholder="Card number"
              className="mb-3 w-full border border-[#2a2a2a] bg-transparent px-4 py-3 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
            />
            <div className="grid grid-cols-2 gap-3">
              <input
                required
                placeholder="MM / YY"
                className="border border-[#2a2a2a] bg-transparent px-4 py-3 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
              />
              <input
                required
                placeholder="CVC"
                className="border border-[#2a2a2a] bg-transparent px-4 py-3 text-sm text-[#f5f5f0] placeholder:text-[#f5f5f0]/40 focus:border-[#c9a962] focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-[#c9a962] py-4 text-sm font-medium tracking-wider text-black transition hover:bg-[#e8d5a3]"
          >
            PLACE ORDER — ${subtotal.toLocaleString()}
          </button>
        </form>

        {/* Order summary */}
        <div className="lg:col-span-2">
          <div className="border border-[#2a2a2a] p-6">
            <h2 className="mb-4 text-xs tracking-[0.15em] text-[#c9a962]">
              ORDER SUMMARY
            </h2>
            <div className="space-y-3">
              {items.map((item) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <span className="text-[#f5f5f0]/70">
                    {item.name} × {item.quantity}
                  </span>
                  <span>${(item.price * item.quantity).toLocaleString()}</span>
                </div>
              ))}
            </div>
            <div className="mt-6 flex justify-between border-t border-[#2a2a2a] pt-4 text-lg font-medium">
              <span>Total</span>
              <span>${subtotal.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
